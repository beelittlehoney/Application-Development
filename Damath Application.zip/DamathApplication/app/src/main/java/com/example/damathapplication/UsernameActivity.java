package com.example.damathapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UsernameActivity extends AppCompatActivity {

    private EditText player1UsernameEditText;
    private EditText player2UsernameEditText;
    private Button startGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_username);

        player1UsernameEditText = findViewById(R.id.player1Username);
        player2UsernameEditText = findViewById(R.id.player2Username);
        startGameButton = findViewById(R.id.startGameButton);

        startGameButton.setOnClickListener(v -> {
            String player1Username = player1UsernameEditText.getText().toString().trim();
            String player2Username = player2UsernameEditText.getText().toString().trim();

            if (player1Username.isEmpty() || player2Username.isEmpty()) {
                Toast.makeText(this, "Please enter usernames for both players.", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(UsernameActivity.this, MainActivity.class);
                intent.putExtra("PLAYER1_USERNAME", player1Username);
                intent.putExtra("PLAYER2_USERNAME", player2Username);
                startActivity(intent);
                finish();
            }
        });
    }
}